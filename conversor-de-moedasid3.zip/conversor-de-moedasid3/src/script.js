function Converter() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmRealNumerico = parseFloat(valor);

  var valorEmDolar = valorEmRealNumerico / 5;
  console.log(valorEmDolar);

  var valorConvertido = document.getElementById("valorConvertido");
  var valorConvertidoEmReal =
    valorEmRealNumerico + " Reais é igual a US$ " + valorEmDolar;
  valorConvertido.innerHTML = valorConvertidoEmReal;
}

function Converter2() {
  var valorElemento = document.getElementById("valor");
  var valor= valorElemento.value;
  var valorEmDolarNumerico = parseFloat(valor);

  var valorEmReal = valorEmDolarNumerico * 5;
  console.log(valorEmReal);

  var valorConvertido2 = document.getElementById("valorConvertido2");
  var valorConvertidoEmDolar =
    valorEmDolarNumerico + " Dolares é igual a R$ " + valorEmReal;
  valorConvertido.innerHTML = valorConvertidoEmDolar;
}
